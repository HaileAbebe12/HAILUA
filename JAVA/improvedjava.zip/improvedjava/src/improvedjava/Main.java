package improvedjava;
import java.util.InputMismatchException;
import java.util.Scanner;

class Infoaccepter {
    private int  age, year, sem;
    private String fname,UID,  sname, ID,lname, dep,sex;

    int Info() {
            Scanner scan = new Scanner(System.in);
            try {
                // Validate first name
                while (true) {
                    System.out.print("Enter your first name:");
                    String valid = scan.nextLine();
                    if (valid.matches("[a-zA-Z]+")) {
                        fname = valid;
                        break;
                    } else {
                        System.out.print("Please enter a valid first name:");
                    }
                }

                while (true) {
                    System.out.print("Enter your second name:");
                    String val2 = scan.nextLine();
                    if (val2.matches("[a-zA-Z]+")) {
                        sname = val2;
                        break;
                    } else {
                        System.out.print("Please enter a valid srcond name:");
                    }

                }

                while (true) {
                    System.out.print("Enter your last name:");
                    String val3 = scan.nextLine();
                    if (val3.matches("[a-zA-Z]+")) {
                        lname = val3;
                        break;
                    } else {
                        System.out.print("Please enter a valid srcond name.");
                    }
                }
                while (true) {
                    System.out.print("Enter your sex (M/F):");
                    String validsex = scan.nextLine();
                    if (validsex.equalsIgnoreCase("F") || validsex.equalsIgnoreCase("M")) {
                        sex = validsex;
                        break;
                    } else {
                        System.out.print("Please enter valid sex (M/F).");
                    }
                }
                while (true) {
                    System.out.print("Enter your age:");
                    int val4 = scan.nextInt();
                    if (val4 >= 18 && val4 <= 60) {
                        age = val4;
                        break;
                    } else {
                        System.out.print("Please enter a valid age:");
                    }
                }
                while (true) {
                    System.out.print("Enter your id no:");
                    String VAID = scan.nextLine();
                    if (VAID.matches("\\d{4}")) {
                        ID = VAID;
                        break;
                    } else {
                        System.out.print(" Please enter a valid id no:");
                    }

                }
                while (true) {
                    System.out.print("Enter your uid:");
                    String VAUID = scan.nextLine();

                    if (VAUID.matches("\\d{6}")) {
                        UID = VAUID;
                        break;
                    } else {
                        System.out.print("Please enter a valid uid in six digit:");
                    }
                }
                while (true) {
                    System.out.print("Enter year:");
                    int validyear = scan.nextInt();
                    if (validyear >= 1 && validyear <= 7) {
                        year = validyear;
                        break;
                    } else {
                        System.out.print("Please enter year 1-7:");
                    }
                }
                while (true) {
                    System.out.print("Enter sem:");
                    int validsem = scan.nextInt();
                    if (validsem == 1 || validsem == 2) {
                        sem = validsem;
                        break;
                    } else {
                        System.out.print("Please enter a valid sem 1 or 2");
                    }

                }
                scan.nextLine(); // Consume the newline character left by nextInt()
                while (true) {
                    System.out.print("Enter your department:");
                    String valdep = scan.nextLine();
                    if (valdep.matches("[a-zA-Z]+")) {
                        dep = valdep;
                        break;
                    } else {
                        System.out.print("please enter valid department name ");
                    }
                }

            } catch (InputMismatchException e) {
                System.out.print("Invalid input. Please enter a valid numeric value.");
                return -1; // Return an error code
            } catch (Exception e) {
                System.out.print("An unexpected error occurred.");
                e.printStackTrace();
                return -1; // Return an error code
            }
            return 0;

    }


    void profile() {
        System.out.println("--------------------------------------------------");
        System.out.println("First Name-----------------------:" + fname);
        System.out.println("Second Name----------------------:" + sname);
        System.out.println("Last Name------------------------: " + lname);
        System.out.println("your sex-------------------------:   "+sex);
        System.out.println("Age------------------------------: " + age);
        System.out.println("ID-------------------------------: " + ID);
        System.out.println("UID------------------------------: " + UID);
        System.out.println("Year-----------------------------: " + year);
        System.out.println("Semester--------------------------: " + sem);
        System.out.println("Department------------------------: " + dep);
        System.out.println(" PLEASE  COLLECT  YOUR SLIP   FROM  DEPARTEMENT.");
    }
    void help(){
        System.out.println("--------------------------------------------------------------");
        System.out.println("frist of all you have to login into the page for registration ");
        System.out.println("when you logged in into the page you will get some area to enter ");
        System.out.println("your full information .then enter  your full information as you asked");
        System.out.println("but if you want to exit select the exit and logout the  page and try it ");
        System.out.println(" again when you want ..");
        System.out.println("-----------------------------------------------------------------------");
}
void about(){
    System.out.println("ABOUT.");
    System.out.println("this is HU registration system ");
    System.out.println("develooped by: haile abebe ");
    System.out.println(" developed  in .2023 ");
    System.out.println(" this system can be improved in future ");

    }
}
public class Main {
    public static void main(String[] args) {
        System.out.println("--------------------------------------------------------------");
        System.out.println("W E L  C O M E   T O  R E G I S T R A T I O N    S Y S T E M");
        System.out.println("--------------------------------------------------------------");
        System.out.println("1. LOGIN!");
        System.out.println("2.HELP..");
        System.out.println("3. SBOUT US");
        System.out.println("4. EXIT!");
        int enter;
        Scanner check = new Scanner(System.in);
        enter = check.nextInt();

        switch (enter) {
            case 1://login
                System.out.println("----------------------------------------------");
                System.out.println("T H I S   I S   T H E   R E G I S T R A T I O N");
                System.out.println("PLEASE   ENTER   ALL   YOUR      INFORMATION");
                System.out.println("------------------------------------------------");
                Infoaccepter obj = new Infoaccepter();

                int result = obj.Info();

                if (result == 0) {
                    System.out.println("Y O U  R E G I S T E R E D  S U C C E S S F U L L Y!!");
                    System.out.println("Do you want to see your profile?");
                    System.out.println("1: Yes");
                    System.out.println("2: No");
                    int pro;
                    Scanner chose = new Scanner(System.in);
                    pro = chose.nextInt();

                    switch (pro) {
                        case 1:
                            System.out.println("T H I S  Y O U R F U L L I N F O R M A T I O N");
                            obj.profile();// Call profile method
                            System.out.println("login for other student .");
                            System.out.println("1. Continue");
                            System.out.println("2. Logout");
                            int cont;
                            Scanner obj1 = new Scanner(System.in);
                            cont = obj1.nextInt();

                            if (cont == 1) {
                                obj.Info();
                                System.out.println("Do you want to see your profile?");
                                System.out.println("1: Yes");
                                System.out.println("2: No");
                                int pro2;
                                Scanner chose2 = new Scanner(System.in);
                                pro2 = chose2.nextInt();
                                switch (pro2) {
                                    case 1:
                                        System.out.println("T H I S  Y O U R F U L L I N F O R M A T I O N");
                                        obj.profile();
                                    case 2:
                                        System.out.println("=============================================");
                                        System.out.println("PLEASE RELEASE THE PORTAL FOR OTHER STUDENT ");
                                }

                            } else if (cont == 2) {
                                System.out.println("------------------------------------------------");
                                System.out.println("Y O U  S U C C E S S F U L L Y  L O G G E D O U T");
                                System.out.println("PLEASE    CONTACT      DEPARTIMENT          HEAD ");
                                System.out.println("--------------------------------------------------");
                            } else {
                                break;
                            }
                            break;
                        case 2:
                            System.out.println("=======================================================");
                            System.out.println("Y O U  R E G I S T E R R E D  S U C C E S S F U L L Y .");
                            System.out.println("========================================================");
                            System.out.println("Login for other students.");
                            System.out.println("1. Continue");
                            System.out.println("2. Logout");
                            //look here
                            Scanner obj2 = new Scanner(System.in);
                            cont = obj2.nextInt();

                            while (cont == 1) { //if error co if
                                obj.Info();
                            }
                            if (cont == 2) { // else if
                                System.out.println("------------------------------------------------");
                                System.out.println("Y O U  S U C C E S S F U L L Y  L O G G E D O U T");
                                System.out.println("--------------------------------------------------");
                            } else {
                                break;
                            }
                            break;
                        default:
                            System.out.println("B R E A K E D.");
                    }
                } else {
                    System.out.println("Please try again.");
                }
                break;
            case 2:
                Infoaccepter obhelp = new Infoaccepter();
                obhelp.help();
                break;
            case 3:
                Infoaccepter ob_ab = new Infoaccepter();
                ob_ab.about();

            case 4:
                System.out.println("-------------------");
                System.out.println("T=H=E  P=R=O=C=C=E=S=S====F=I=N=I=S=H=D=");
                System.out.println("-------------------");

                break;

            default:
                System.out.println("E R R O R !!");

        }

    }

}
